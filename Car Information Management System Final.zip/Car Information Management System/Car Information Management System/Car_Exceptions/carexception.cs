﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Exceptions
{
    public class carexception:ApplicationException
    {
        public carexception()
           : base()
        {
        }

        public carexception(string message)
            : base(message)
        {
        }
        public carexception(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
