﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car_BAL;
using Car_Entities;
using Car_Exceptions;

namespace Car_PL
{
    class Program
    {
        private void CarFunctions()
        {
            Console.WriteLine("======================Car Information Management System======================");
            Console.WriteLine("===========================Admin Login======================");
            int ch;
            do
            {
                DisplayMenu();
                Console.Write("\nChoose the task to perform:");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        AddCar();
                        break;
                    case 2:
                        UpdateCar();
                        break;
                    case 3:
                        DeleteCar();
                        break;
                    case 4:
                        SearchCarByModel();
                        break;
                    case 5:
                        SearchCarByManufacturerAndType();
                        break;
                    case 6:
                        GetListCar();
                        break;
                    default:
                        Console.WriteLine("Enter correct option");
                        break;
                }
                Console.Write("\nDo you want to perform other tasks(Yes or No):");
                Console.ReadLine();
            } while (ch > 0 & ch < 7);
        }
        private void DisplayMenu()
        {
            Console.WriteLine("\n....................................");
            Console.WriteLine("1.Add  Car");
            Console.WriteLine("2.UpdateCar");
            Console.WriteLine("3.Delete Car");
            Console.WriteLine("4.Search Car By Model");
            Console.WriteLine("5.Search Car By ManufacturerAndType");
            Console.WriteLine("6.GetList ");
        }
        private void AddCar()
        {
            car objcar = new car();
            try
            {
                Console.WriteLine("\n======================Adding NewCar Details======================");
                Console.Write("\nEnter ManufacturerName  :");
                objcar.ManufacturerName = Console.ReadLine();
                Console.Write("Enter Model :");
                objcar.Model = Console.ReadLine();
                Console.Write("Enter Type(Hatchback,Sedan OR SUV) :");
                objcar.Type = Console.ReadLine();
                Console.Write("Enter Engine :");
                objcar.Engine = Console.ReadLine();
                Console.Write("Enter BHP :");
                objcar.BHP = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Transmission(Manual OR Automatic) :");
                objcar.Transmission = Console.ReadLine();
                Console.Write("Enter Mileage :");
                objcar.Mileage = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter No.of Seats :");
                objcar.Seats = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter AirBagDetails :");
                objcar.AirBagDetails = Console.ReadLine();
                Console.Write("Enter BootSpace :");
                objcar.BootSpace = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter CarRoofTop(Open OR Close) :");
                objcar.CarRoofTop = Console.ReadLine();
                Console.Write("Enter Price :");
                objcar.Price = Convert.ToDouble(Console.ReadLine());

                bool CarAdded = carbal.AddCarBAL(objcar);
                if (CarAdded == true)
                {
                    Console.WriteLine("\nNew Car Details Added Successfully");
                }
                else
                {
                    Console.WriteLine("\nCar Details Could not be added");
                }
            }
            catch (carexception objCarEx)
            {
                throw new carexception(objCarEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }


        }
        private void UpdateCar()
        {
            car objCar = new car();
            try
            {

                Console.WriteLine("\n======================Updating Car Details======================");
                string UpdateModel;
                Console.WriteLine("\nEnter the model you want to modify");
                UpdateModel = Console.ReadLine();
                objCar = carbal.SearchCarByModelBAL(UpdateModel);
                if (objCar != null)
                {
                    Console.WriteLine("\nManufacturerName :");
                    objCar.ManufacturerName = Console.ReadLine();
                    Console.WriteLine("Enter Model :");
                    objCar.Model = Console.ReadLine();
                    Console.WriteLine("Enter Type(Hatchback,Sedan,Maruthi OR SUV) :");
                    objCar.Type = Console.ReadLine();
                    Console.WriteLine("Enter Engine :");
                    objCar.Engine = Console.ReadLine();
                    Console.WriteLine("Enter BHP :");
                    objCar.BHP = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Transmission(Manual OR Automatic) :");
                    objCar.Transmission = Console.ReadLine();
                    Console.WriteLine("Enter Mileage :");
                    objCar.Mileage = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter No.of Seats :");
                    objCar.Seats = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter AirBagDetails :");
                    objCar.AirBagDetails = Console.ReadLine();
                    Console.WriteLine("Enter BootSpace :");
                    objCar.BootSpace = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter CarRoofTop :");
                    objCar.CarRoofTop = Console.ReadLine();
                    Console.WriteLine("Enter Price :");
                    objCar.Price = Convert.ToDouble(Console.ReadLine());

                    bool CarUpdated = carbal.UpdateCarBAL(objCar);
                    if (CarUpdated == true)
                    {
                        Console.WriteLine("\nCar Details Updated Successfully");
                    }
                    else
                    {
                        Console.WriteLine("\nCar Details Cannot be updated");
                    }
                }
                else
                {
                    Console.WriteLine("\n Car details Based on given model is not available");
                }
            }
            catch (carexception objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void DeleteCar()
        {
            car objCar = new car();
            try
            {

                Console.WriteLine("\n======================Deleting Car Details======================");
                string DeleteModel;
                Console.WriteLine("\nEnter the car model you want to delete");
                DeleteModel = Console.ReadLine();
                objCar = carbal.SearchCarByModelBAL(DeleteModel);
                if (objCar != null)
                {
                    Console.WriteLine("\nAre you sure that you want to delete the selected car (Yes OR No)");
                    string s = Console.ReadLine();
                    if ((s == "yes") || (s == "Yes"))
                    {
                        bool CarDeleted = carbal.DeleteCarBAL(DeleteModel);
                        if (CarDeleted == true)
                            Console.WriteLine("\nCar Details deleted Successfully");
                        else
                            Console.WriteLine("\nCar Details Cannot be deleted");
                    }
                }
                else
                {
                    Console.WriteLine("\nCar details Based on given model is not available");
                }
            }
            catch (carexception objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void SearchCarByManufacturerAndType()
        {
            Console.WriteLine("\n======================Searching for Car Details By Manufacturer And Type======================");
            try
            {
                Console.WriteLine("\nEnter the Manufacturer :");
                string manufacturerName = Console.ReadLine();
                Console.WriteLine("Enter the Type:");
                string type = Console.ReadLine();
                List<car> cars = carbal.GetListBAL();
                if (cars == null)
                {
                    Console.WriteLine("Car List is Empty");
                }
                else
                {
                    foreach (var car in cars)
                    {
                        if (car.ManufacturerName == manufacturerName && car.Type == type)
                        {
                            Console.WriteLine("\nManufacturerName: " + car.ManufacturerName);
                            Console.WriteLine("Model: " + car.Model);
                            Console.WriteLine("Type:" + car.Type);
                            Console.WriteLine("CarRoofTop :" + car.CarRoofTop);
                            Console.WriteLine("Price:" + car.Price);
                        }
                    }
                }
            }
            catch (carexception objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void SearchCarByModel()
        {
            Console.WriteLine("\n======================Searching for Car Details By Model======================");

            try
            {
                string SearchModel;
                Console.WriteLine("\nEnter the model of car you want to modify");
                SearchModel = Console.ReadLine();
                car objCar = carbal.SearchCarByModelBAL(SearchModel);
                if (objCar != null)
                {
                    Console.WriteLine("\nManufacturerName: " + objCar.ManufacturerName);
                    Console.WriteLine("Model: " + objCar.Model);
                    Console.WriteLine("Type:" + objCar.Type);
                    Console.WriteLine("Engine: " + objCar.Engine);
                    Console.WriteLine("BHP:" + objCar.BHP);
                    Console.WriteLine("Transmission:" + objCar.Transmission);
                    Console.WriteLine("Mileage:" + objCar.Mileage);
                    Console.WriteLine("Seats:" + objCar.Seats);
                    Console.WriteLine("AirBagDetails:" + objCar.AirBagDetails);
                    Console.WriteLine("BootSpace:" + objCar.BootSpace);
                    Console.WriteLine("CarRoofTop :" + objCar.CarRoofTop);
                    Console.WriteLine("Price:" + objCar.Price);
                }
                else
                    Console.WriteLine("\nCar cannot be searched based on given model");
            }
            catch (carexception objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        private void GetListCar()
        {
            //Car objCar = new Car();           
            List<car> cars = carbal.GetListBAL();
            if (cars == null)
            {
                Console.WriteLine("Car List is Empty");
            }
            else
            {
                foreach (var car in cars)
                {                   
                        Console.WriteLine("\nManufacturerName: " + car.ManufacturerName);
                        Console.WriteLine("Model: " + car.Model);
                        Console.WriteLine("Type:" + car.Type);
                        Console.WriteLine("CarRoofTop :" + car.CarRoofTop);
                        Console.WriteLine("Price:" + car.Price);
                    
                }
            }
        }

        static void Main(string[] args)
        {
            Program objpg = new Program();
            objpg.CarFunctions();
            Console.ReadLine();
        }
    }
}
