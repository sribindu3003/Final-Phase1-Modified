﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car_Entities;
using Car_Exceptions;
using Car_DAL;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Car_DAL
{
    public class cardal
    {
        public static string FileName = @"CarMS";
        public static List<car> objCars = new List<car>();
        public bool AddCarDAL(car objcar)
        {
            bool carAdded=false;
            try
            {
                objCars.Add(objcar);
                Serialization();
                carAdded = true;
            }
            catch (carexception objCarEx)
            {
                throw new carexception(objCarEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }

            return carAdded;
        }
        public bool UpdateCarDAL(car objCar)
        {
            Deserialization();
            bool carUpdated = false;
            try
            {
                car objNewCar = objCars.Find(c => c.Model == objCar.Model);
                if (objCar != null)
                {
                    objNewCar.ManufacturerName = objCar.ManufacturerName;
                    objNewCar.Model = objCar.Model;
                    objNewCar.Type = objCar.Type;
                    objNewCar.Engine = objCar.Engine;
                    objNewCar.BHP = objCar.BHP;
                    objNewCar.Transmission = objCar.Transmission;
                    objNewCar.Mileage = objCar.Mileage;
                    objNewCar.Seats = objCar.Seats;
                    objNewCar.AirBagDetails = objCar.AirBagDetails;
                    objNewCar.BootSpace = objCar.BootSpace;
                    objNewCar.CarRoofTop = objCar.CarRoofTop;
                    objNewCar.Price = objCar.Price;
                }
                carUpdated = true;
                Serialization();
            }
            catch (carexception objCarEx)
            {
                throw new carexception(objCarEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carUpdated;
        }
        public bool DeleteCarDAL(string model)
        {
            Deserialization();
            bool carDeleted = false;
            try
            {
                car objCar = objCars.Find(c => c.Model == model);
                if (objCar != null)
                {
                    objCars.Remove(objCar);
                    carDeleted = true;
                    Serialization();
                }
            }
            catch (carexception objCarEx)
            {
                throw new carexception(objCarEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carDeleted;
        }       
        public car SearchCarByModelDAL(string model)
        {
            Deserialization();
            try
            {
                car objCar = objCars.Find(c => c.Model == model);
                return objCar;
            }
            catch (carexception objCarEx)
            {
                throw new carexception(objCarEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public List<car> GetListDAL()
        {
            Deserialization();
            try
            {
                
                return objCars;
            }
            catch (carexception objCarEx)
            {
                throw new carexception(objCarEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public void Serialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, objCars);
                fs.Close();
                //Carlist.Clear();
            }
            catch (carexception objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }
        public void Deserialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                //Carlist.Clear();
                objCars = bf.Deserialize(fs) as List<car>;
                fs.Close();
            }
            catch (carexception objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }

        }
    }
}
